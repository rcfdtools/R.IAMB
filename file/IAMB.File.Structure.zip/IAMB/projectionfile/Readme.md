# Coordinates projection file 

`\projectionfile`: carpeta para el almacenamiento de los archivos de proyección de coordenadas .prj. El uso de esta carpeta previene errores en el desarrollo de modelos hidráulicos usando HEC-RAS, debido a que estos modelos también utilizan la misma extensión.