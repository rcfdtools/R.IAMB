# Archivos CAD

`\cad`: carpeta para el almacenamiento de archivos CAD generados.
